import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import Stripe from 'stripe';
import { db } from '@/lib/db';
import { users } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

// ─── Plan Configuration ───────────────────────────────────────────────────────

const PLANS = {
  personal: {
    priceId: process.env.STRIPE_PRICE_PERSONAL!,
    name: 'Personal',
    amount: 2900, // €29 in cents
  },
  business: {
    priceId: process.env.STRIPE_PRICE_BUSINESS!,
    name: 'Business',
    amount: 9900,
  },
  creator: {
    priceId: process.env.STRIPE_PRICE_CREATOR!,
    name: 'Creator',
    amount: 14900,
  },
} as const;

type PlanKey = keyof typeof PLANS;

// ─── Request Schema ────────────────────────────────────────────────────────────

const CheckoutSchema = z.object({
  plan: z.enum(['personal', 'business', 'creator']),
});

// ─── POST /api/checkout ───────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }

    const body = await req.json();
    const parsed = CheckoutSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid plan selection.' }, { status: 400 });
    }

    const { plan } = parsed.data;
    const planConfig = PLANS[plan];

    // Fetch user for email pre-fill
    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    if (!user) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }

    // If user already has a Stripe customer, use it
    let customerParam: Stripe.Checkout.SessionCreateParams['customer'] | undefined;
    let customerEmailParam: string | undefined;

    if (user.stripeCustomerId) {
      customerParam = user.stripeCustomerId;
    } else {
      customerEmailParam = user.email;
    }

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://mind-reply.com';

    // ── Create Stripe Checkout Session ───────────────────────────────────────
    // RULE: webhook is source of truth — success page does NOT write DB state
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: planConfig.priceId,
          quantity: 1,
        },
      ],
      ...(customerParam ? { customer: customerParam } : {}),
      ...(customerEmailParam ? { customer_email: customerEmailParam } : {}),
      metadata: {
        userId,              // critical: webhook uses this to write DB
        plan,
      },
      subscription_data: {
        metadata: {
          userId,            // also on subscription for update/delete webhooks
          plan,
        },
      },
      success_url: `${siteUrl}/dashboard?upgraded=1`,
      cancel_url: `${siteUrl}/pricing?cancelled=1`,
      allow_promotion_codes: true,
      billing_address_collection: 'auto',
    });

    return NextResponse.json({ url: session.url });
  } catch (err) {
    console.error('[Checkout] error:', err);
    return NextResponse.json(
      { error: 'Unable to initiate checkout. Please retry.' },
      { status: 500 }
    );
  }
}
