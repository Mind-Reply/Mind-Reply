import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { db } from '@/lib/db';
import { signals, patternSnapshots, messages } from '@/lib/db/schema';
import { eq, and, gte, desc } from 'drizzle-orm';
import { subconsciousService } from '@/services/subconscious.service';
import type { DetectedSignal } from '@/services/subconscious.service';
import { createId } from '@/lib/utils';

export const dynamic = 'force-dynamic';

// ─── GET /api/subconscious/summary ────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const { userId } = await auth();
    if (!userId) {
      return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const window = searchParams.get('window') === '30' ? 30 : 7;

    const since = new Date();
    since.setDate(since.getDate() - window);

    // ── Fetch signals from window ──────────────────────────────────────────
    const userSignals = await db
      .select()
      .from(signals)
      .where(
        and(
          eq(signals.userId, userId),
          gte(signals.createdAt, since)
        )
      )
      .orderBy(desc(signals.createdAt))
      .limit(200);

    // ── Fetch message count in window ────────────────────────────────────
    const userMessages = await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.userId, userId),
          eq(messages.role, 'user'),
          gte(messages.createdAt, since)
        )
      );

    const detectedSignals: DetectedSignal[] = userSignals.map((s) => ({
      type: s.type,
      description: s.description,
      intensity: s.intensity ?? 0.5,
    }));

    const snapshot = subconsciousService.computeSnapshot(
      detectedSignals,
      userMessages.length,
      window as 7 | 30
    );

    // ── Persist pattern snapshot ─────────────────────────────────────────
    await db.insert(patternSnapshots).values({
      id: createId(),
      userId,
      windowDays: window,
      avoidanceScore: snapshot.avoidanceScore,
      tensionScore: snapshot.tensionScore,
      overloadScore: snapshot.overloadScore,
      delayScore: snapshot.delayScore,
      dominantSignal: snapshot.dominantSignal ?? undefined,
      messageCount: snapshot.messageCount,
      meta: { computedAt: new Date().toISOString() },
    }).catch(() => {}); // non-blocking

    // ── Return unacknowledged signals for UI display ──────────────────────
    const unacknowledged = userSignals
      .filter((s) => !s.acknowledged)
      .map((s) => ({
        id: s.id,
        type: s.type,
        description: s.description,
        intensity: s.intensity,
        createdAt: s.createdAt,
      }));

    return NextResponse.json({
      summary: {
        dominantSignal: snapshot.dominantSignal,
        avoidanceScore: Math.round(snapshot.avoidanceScore * 100),
        tensionScore: Math.round(snapshot.tensionScore * 100),
        overloadScore: Math.round(snapshot.overloadScore * 100),
        delayScore: Math.round(snapshot.delayScore * 100),
        messageCount: snapshot.messageCount,
        windowDays: window,
      },
      unacknowledgedSignals: unacknowledged,
      totalSignals: userSignals.length,
    });
  } catch (err) {
    console.error('[Subconscious] summary error:', err);
    return NextResponse.json({ error: 'Summary unavailable.' }, { status: 500 });
  }
}
