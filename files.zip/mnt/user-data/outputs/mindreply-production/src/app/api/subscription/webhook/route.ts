import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { db } from '@/lib/db';
import { users, subscriptions, logs, notifications } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { createId } from '@/lib/utils';

export const dynamic = 'force-dynamic';

// ─── Stripe client ────────────────────────────────────────────────────────────

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

// ─── Plan resolution ──────────────────────────────────────────────────────────

const PLAN_PRICE_MAP: Record<string, 'personal' | 'business' | 'creator'> = {
  [process.env.STRIPE_PRICE_PERSONAL!]: 'personal',
  [process.env.STRIPE_PRICE_BUSINESS!]: 'business',
  [process.env.STRIPE_PRICE_CREATOR!]: 'creator',
};

const PLAN_LIMITS: Record<string, number> = {
  personal: 999999,
  business: 999999,
  creator: 999999,
  free: 10,
};

function resolvePlan(priceId: string | null | undefined): 'personal' | 'business' | 'creator' | 'free' {
  if (!priceId) return 'free';
  return PLAN_PRICE_MAP[priceId] ?? 'free';
}

// ─── POST /api/subscription/webhook ──────────────────────────────────────────

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature');

  if (!sig) {
    return NextResponse.json({ error: 'Missing Stripe signature.' }, { status: 400 });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('[Webhook] signature verification failed:', err);
    return NextResponse.json({ error: 'Invalid signature.' }, { status: 400 });
  }

  // ── Log raw event (always, before processing) ─────────────────────────────
  await db.insert(logs).values({
    id: createId(),
    userId: null,
    type: `stripe.${event.type}`,
    meta: { eventId: event.id, type: event.type },
  }).catch(() => {});

  try {
    switch (event.type) {
      case 'checkout.session.completed':
        await handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session);
        break;

      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object as Stripe.Subscription);
        break;

      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
        break;

      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object as Stripe.Invoice);
        break;

      default:
        // Unhandled events are acceptable — Stripe sends many
        break;
    }
  } catch (err) {
    console.error(`[Webhook] handler error for ${event.type}:`, err);
    // Return 200 to prevent Stripe retry storms — log the failure
    await db.insert(logs).values({
      id: createId(),
      userId: null,
      type: 'stripe.handler_error',
      meta: { eventId: event.id, eventType: event.type, error: String(err) },
    }).catch(() => {});
  }

  return NextResponse.json({ received: true });
}

// ─── Handlers ─────────────────────────────────────────────────────────────────

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const userId = session.metadata?.userId;
  const subscriptionId = session.subscription as string;

  if (!userId || !subscriptionId) {
    console.error('[Webhook] checkout.completed missing userId or subscriptionId');
    return;
  }

  // Fetch full subscription from Stripe for authoritative state
  const stripeSub = await stripe.subscriptions.retrieve(subscriptionId, {
    expand: ['items.data.price'],
  });

  const priceId = stripeSub.items.data[0]?.price.id;
  const plan = resolvePlan(priceId);
  const customerId = session.customer as string;

  // ── Write subscription record ────────────────────────────────────────────
  await db
    .insert(subscriptions)
    .values({
      id: subscriptionId,
      userId,
      stripeCustomerId: customerId,
      plan,
      status: stripeSub.status,
      currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
      currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
      cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
      meta: { priceId, checkoutSessionId: session.id },
    })
    .onConflictDoUpdate({
      target: subscriptions.id,
      set: {
        status: stripeSub.status,
        plan,
        currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
        updatedAt: new Date(),
      },
    });

  // ── Update user record ───────────────────────────────────────────────────
  await db
    .update(users)
    .set({
      plan,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscriptionId,
      subscriptionStatus: stripeSub.status,
      subscriptionCurrentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
      operationsLimit: PLAN_LIMITS[plan],
      updatedAt: new Date(),
    })
    .where(eq(users.id, userId));

  // ── Send welcome notification ────────────────────────────────────────────
  await db.insert(notifications).values({
    id: createId(),
    userId,
    type: 'system',
    title: 'Plan activated.',
    body: `Your ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan is now active. Full access unlocked.`,
    actionUrl: '/dashboard',
  }).catch(() => {});

  // ── Log ──────────────────────────────────────────────────────────────────
  await db.insert(logs).values({
    id: createId(),
    userId,
    type: 'plan_upgraded',
    meta: { plan, subscriptionId, priceId },
  }).catch(() => {});
}

async function handleSubscriptionUpdated(stripeSub: Stripe.Subscription) {
  const userId = stripeSub.metadata?.userId;
  const priceId = (stripeSub as any).items?.data?.[0]?.price?.id;
  const plan = resolvePlan(priceId);

  if (userId) {
    await db
      .update(users)
      .set({
        plan: stripeSub.status === 'active' ? plan : 'free',
        subscriptionStatus: stripeSub.status,
        subscriptionCurrentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        operationsLimit: stripeSub.status === 'active' ? PLAN_LIMITS[plan] : PLAN_LIMITS.free,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  await db
    .update(subscriptions)
    .set({
      status: stripeSub.status,
      plan: plan,
      currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
      currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
      cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
      updatedAt: new Date(),
    })
    .where(eq(subscriptions.id, stripeSub.id));
}

async function handleSubscriptionDeleted(stripeSub: Stripe.Subscription) {
  const userId = stripeSub.metadata?.userId;

  if (userId) {
    await db
      .update(users)
      .set({
        plan: 'free',
        subscriptionStatus: 'cancelled',
        stripeSubscriptionId: null,
        operationsLimit: PLAN_LIMITS.free,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await db.insert(notifications).values({
      id: createId(),
      userId,
      type: 'system',
      title: 'Subscription ended.',
      body: 'Your plan has ended. Reactivate anytime from the pricing page.',
      actionUrl: '/pricing',
    }).catch(() => {});
  }

  await db
    .update(subscriptions)
    .set({
      status: 'cancelled',
      cancelledAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(subscriptions.id, stripeSub.id));
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  const customerId = invoice.customer as string;

  // Find user by Stripe customer ID
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.stripeCustomerId, customerId))
    .limit(1);

  if (!user) return;

  await db.insert(notifications).values({
    id: createId(),
    userId: user.id,
    type: 'system',
    title: 'Payment failed.',
    body: 'Your most recent payment could not be processed. Please update your payment method.',
    actionUrl: '/pricing',
  }).catch(() => {});

  await db.insert(logs).values({
    id: createId(),
    userId: user.id,
    type: 'payment_failed',
    meta: { invoiceId: invoice.id, customerId },
  }).catch(() => {});
}
