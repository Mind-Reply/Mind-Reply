import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { db } from '@/lib/db';
import { signals } from '@/lib/db/schema';
import { eq, and, inArray } from 'drizzle-orm';
import { z } from 'zod';

export const dynamic = 'force-dynamic';

const AcknowledgeSchema = z.object({
  signalIds: z.array(z.string()).min(1).max(50),
});

// ─── POST /api/subconscious/acknowledge ───────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const { userId } = await auth();
    if (!userId) {
      return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }

    const body = await req.json();
    const parsed = AcknowledgeSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid request.' }, { status: 400 });
    }

    const { signalIds } = parsed.data;

    await db
      .update(signals)
      .set({
        acknowledged: true,
        acknowledgedAt: new Date(),
      })
      .where(
        and(
          eq(signals.userId, userId),
          inArray(signals.id, signalIds)
        )
      );

    return NextResponse.json({ acknowledged: signalIds.length });
  } catch (err) {
    console.error('[Subconscious] acknowledge error:', err);
    return NextResponse.json({ error: 'Acknowledge failed.' }, { status: 500 });
  }
}
